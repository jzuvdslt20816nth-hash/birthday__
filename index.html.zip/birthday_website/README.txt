BIRTHDAY SURPRISE WEBSITE ❤️

How to use:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge/Safari.
3. Keep the assets folder next to index.html.
4. The 3 photos and i_love_u_baby.mp3 are already included.

The website is designed for mobile first and also works on desktop.
